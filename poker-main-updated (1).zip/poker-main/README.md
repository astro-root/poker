# Poker Colosseum

Poker Colosseum — Online Texas Hold’em. *Step Into the Colosseum.*

強さを選べる最大7人のAIや、招待リンクで集まる友だちと遊べるテキサスホールデム。ゲーム内チップはバーチャルで、金銭的価値はありません。運営: [astro-root](https://astro-root.com) ・ <https://poker.astro-root.com> ・ ©2026 astro-root

公開ドメイン: [`poker.astro-root.com`](https://poker.astro-root.com)

## できること

- **AI対戦**: 強さを「新兵／剣闘士／百人隊長／皇帝」から、人数を1〜7人から選べます（選択は端末に保存）。開始前の設定画面で変更でき、対戦中も「設定を変更」から戻れます。
- **オンライン対戦（友だち）**: ルームを作って招待リンクを共有。2〜6人。配札・アクション・チップはサーバー（Supabase Edge Function）が管理し、参加者には自分の手札と公開情報だけを返します。
- **学習支援**: 現在の役の説明、勝率シミュレーション、ポットオッズ、AIコーチ、14項目の用語集、役の強さ一覧。
- **ページ**: `/`（ホーム）、`/ai`、`/online`、`/terms`、`/hands`。

### AIの強さ

| 強さ | 判断の方法 |
| --- | --- |
| 新兵 | 手の強さに誤差を加えた緩い判断。降りるべき場面でも付き合いがち |
| 剣闘士 | 手の強さとポットオッズを使う堅実なヒューリスティック |
| 百人隊長 | 勝率をシミュレーション（220回）し、ポットオッズと比べて判断 |
| 皇帝 | 勝率を700回シミュレーション。相手人数・ポット比を考慮したバリューベットとブラフ |

どのAIも、自分の手札と公開情報だけを使い、合法なアクションしか選びません。

## 開発

```bash
npm install
npm run dev          # 開発サーバー
npm test             # ルール・AI・サーバー関数のテスト（Node標準テストランナー）
npm run typecheck    # 型チェック
npm run build        # Vercel向け静的ファイルを dist/ に生成
npm run test:e2e     # Playwright の e2e（初回は npx playwright install chromium）
```

Node.js は `package.json` の `engines` を参照（22.12 以降）。

### e2e とデザイン確認

`npm run test:e2e` は開発サーバーを自動起動し、全ページの表示、横スクロールなし、手札の可視性（A-1）、AI卓での操作、`@axe-core/playwright` による `color-contrast` 検査を行います。オンライン画面は、開発サーバー限定のフィクスチャ `/online?mock=lobby|lobby-joined|playing|finished` で再現します（本番ビルドには含まれません）。

代表的な画面は `docs/design/screenshots/` にあります。デザインの経緯と対応状況は [`docs/design/ISSUES.md`](docs/design/ISSUES.md)、設計判断は [`docs/DECISIONS.md`](docs/DECISIONS.md) を参照してください。

## 構成

```
src/
  poker/     ルールエンジン（カード・役判定・ポット・ベッティング・テーブル・AI・勝率）
  app/       状態、AI対戦の進行、オンライン制御、コーチ、開発用モック
  views/     設定画面、ロビー、卓
  ui/        ヘッダー、静的ページ、カード・席・ボタンのコンポーネント
  supabase/  クライアント、ルームAPI
supabase/    Edge Function（rooms）とDBマイグレーション
test/        ユニット・統合テスト（test/e2e に Playwright）
```

## Supabase とデプロイ

Vercel では Vite プロジェクトとして、ビルドコマンド `npm run build`、出力先 `dist` を使います。`vercel.json` にセキュリティヘッダ（CSP など）とSPA用のrewriteがあります。

オンライン対戦には Supabase の設定が必要です。Anonymous Sign-Ins を有効にし、`.env.example` を `.env.local` にコピーして次を設定します。

- `VITE_SUPABASE_URL` — Project URL
- `VITE_SUPABASE_PUBLISHABLE_KEY` — Publishable key

どちらも未設定なら、AI対戦だけが使えます。Secret key はブラウザー向けの変数に設定しないでください。DBマイグレーションと `rooms` Edge Function のデプロイは [SUPABASE_SETUP.md](SUPABASE_SETUP.md) を参照してください。

## セキュリティの考え方

- 全員の手札と山札はサーバー側にだけあり、応答から自分以外の手札と山札を取り除きます。DBテーブルはRLSで直接アクセスを拒否します。
- 認証は Supabase の匿名ログインです。Edge Function は JWT の `sub`（UUID）・`role`・`exp` を確認しますが、**署名の検証はプラットフォーム（`verify_jwt = true`）に任せています**。この設定は変更しないでください。
- アクションごとにテーブルバージョンとDBリビジョンを比較し、古い操作や同時操作を拒否します。ルーム作成・参加・アクションにはユーザーごとのレート制限があります。
- 表示名は制御文字・双方向制御文字を拒否し、20文字（コードポイント）までです。

## 離席と再接続

- 待機ロビーでは、タブを閉じると退室します。対戦中のリロードやアプリ切替ではフォールドしません。
- 対戦中に退出・不在になった人も、席とチップは保持されます。次のハンドからは配札されず、戻ると（同じ招待リンクを開くか、画面の更新で）次のハンドから復帰します。
- 待機中のルームでは、60秒以上不在の参加者が自動的に外れ、ホストが不在なら在席者に引き継がれます。

## 進捗の目安

| 領域 | 状態 |
| --- | --- |
| ポーカールールとテスト（ファジング含む） | 完了 |
| AI対戦（4段階の強さ、1〜7人） | 実装済み |
| 招待ルーム・サーバー権威のオンライン対戦 | 実装済み |
| 離席・再接続 | 実装済み |
| デザイン（ダーク基調、スマホ固定操作、楕円卓） | 実装済み |
| 公開ルーム一覧・自動マッチング | 未実装 |
| 観戦・オンライン戦績 | 未実装 |
| 実機・複数端末での公開前確認、`functions deploy` の確認（V-02） | 未実施 |


## メンテナンス用スクリプト（`scripts/`）

すべて、リポジトリのルート以外では実行を拒否し、`.env` や秘密情報を扱いません。

| スクリプト | 役割 |
| --- | --- |
| `bash scripts/check-env.sh` | git / Node(22.12+) / npm、任意の supabase・vercel・gh の有無を確認 |
| `bash scripts/status.sh` | ブランチ、変更、リモートとの差分、秘密情報の混入チェック（読み取り専用） |
| `bash scripts/verify.sh` | 型チェック・テスト・ビルド（`RUN_E2E=1` で Playwright も） |
| `bash scripts/make-package.sh [--dry-run]` | 追跡対象のファイルだけをZIP化（秘密情報・生成物を除外） |
| `bash scripts/publish-branch.sh [--execute]` | 専用ブランチへ、一覧を確認したファイルだけコミットしてpush（既定はdry-run、強制pushなし） |

GitHub への push には、事前に `gh auth login` またはSSH鍵などの認証が必要です。トークンをスクリプトやソースに書かないでください。

## ドキュメント

- [`docs/UPDATE_NOTES.md`](docs/UPDATE_NOTES.md): 今回の変更の根拠、未確認事項、デプロイ手順、法務チェックリスト
- `/terms` `/privacy` は**草案**です。公開前に運営者情報の記入と確認が必要です。


## 主な機能（追加分）

ルーム設定ダイアログ（作成時・試合中）、観戦、強制退出、チャット／スタンプ、ルームコード、アクション履歴、役の表示切り替え、ルールページ。詳細と未確認事項は [`docs/UPDATE_NOTES.md`](docs/UPDATE_NOTES.md)。
